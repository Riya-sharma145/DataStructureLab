/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main()
{
   int stack[10],x,n,top=-1;
   
   printf("Enter the size of stack (up to 10):");
   scanf("%d",&n);
   if(n>10 ||n<=0) {
       printf("Invalid size!The stack size must be between 1 and 10.\n");
       return 0;
      
   }
     
     // CREATION OF stack
     
     printf("Enter the element of stack : \n");
     for(int i =0; i<n; i++) {
         scanf("%d",&x);
         top++;
         stack[top] =x;
     }
     
    
       printf("\n1.push:Insertion of element \n2.pop:Deletion of element \n3.peek:Topmost element\n4.underflow:stack is empty\n5.overflow:stack is full\n6.Display\n.Exit");
       
       while(1) {
           int choice;
           printf("\nEnter your choice: ");
           scanf("%d", &choice);
           
           switch(choice) {
             case 1:
            // Push operation [INSERTING AN ELEMENT]   
           if(top== 9) {
               printf("stack overflow!\n");
           } else {
               int a;
               printf("Enter the element to push into the stack:");
               scanf("%d",&a);
               top++;
               stack[top] = a;
           }
           break;
             
             case 2:
             // Pop operation [Deleting an element]
             if(top==-1) {
                 printf("stack undereflow!\n");
             } else{
                 printf("Popped element: %d\n",stack[top]);
                 top--;
             }
             break;
             
             case 3:
             //Peek operation [to identify the top element in stack]
             if(top==-1) {
                 printf("stack is empty.\n");
             } else {
                 printf("Top element is:%d\n",stack[top]);
             }
             break;
              
              case 4:
              //Underflow check
              if(top==-1) {
                  printf("stack is underflow!\n");
              } else {
                  break;
                   
                case 5:
                //overflow check
                if(top==9) {
                    printf("stack is overflowing!\n");
                } else {
                    printf("stack is not overflowing.\n");
                }
                break;
              
             case 6:
             //Display stack elements
             if(top==-1) {
                 printf("stack is empty.\n");
             } else {
                 printf("Elements in the stack: ");
                 for(int i=top; 1>=0; i--) {
                     printf("%d\t",stack[i]);
                 }
                 printf("\n");
             }
             break;
             
             case 7:
             //exit
                exit(0);
             
             default:
                printf("Invalid choice! please try again.\n");
                break;
                
                 }
             }
             
             return 0;
}
}      
