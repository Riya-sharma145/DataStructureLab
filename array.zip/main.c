/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
int i,n,a,x,pos,arr[10];
int main()
{
    int choice;
    printf("Enter the size of the array");
    scanf("%d", &n);
    
    //creation of an array
    printf("\n enter the element for creation of array");
    for(int i=0; i<n; i++)
    {
        scanf("%d",&arr[i]);
    }
    while(1)
    {
     printf("\n1. Insertion of an elementat 1st position\n2. Insertion of an element at any position\n3.Insertion of an element at last position\n5. Deletion of an element at 1st position\n6. Deletion of an element at any position\n7 Deletion of an element at last position\n8. display\n8.exit");
     
     printf("\n\n Enter choice: ");
     scanf("%d",&choice);
     
        switch (choice)  
       { 
            case 1:// Insertion at first position
           printf("\n Enter the element:");
           scanf("%d",&x);
           for(int i=n-1; i>=0;i--)
           {
           arr[i+1] = arr[i];
           }
           arr[0]=x;
           n++;
           break;
            
            case 2:// Insert at any  position
            
            printf("Enter the element");
           scanf("%d",&x);
           printf("Enter the pos:");
           scanf("%d", &pos);
           for(int i=n-1; i>=pos-1; i--)
           {
               arr[i+1]=arr[i];
           }
            arr[pos-1] = x;
            n++;
           break;
           
           case 3:
           printf("\n Enter the element : ");
           scanf("%d",&x);
           arr[n] = x;
           n++;
           break;
           
           case 4:
           printf("\n delete the element");
           for(int i=0;i<=n;i++)
           {
               arr[i]=arr[i+1];
           }
            n--;
            break;
            
           case 5:
            int pos1;
            printf("\n enter the element");
            scanf("%d",&pos);
            for(int i= pos1-1 ; i<n; i++)
            {
                arr[i] = arr[i+1];
            }
             n--;
             break;
             
             case 6:
            printf("\n Delete the element from end");
            n--;
            break;
             
             case 7:
             printf("Displaying the element:");
             for(int i=0; i<n; i++)
             {
                 printf("%d",arr[i]);
             }
              break;
              
               case 8:
               exit(0);
               break; 
               
               default :printf("\n Invalid choice!");
               break;
        }
    }
             return 0;
}
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
          
