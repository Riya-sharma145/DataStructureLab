/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main()
{

     int Q[10],i,n,x,F,R,ch;
     R=F=-1;
     
     printf("enter the size of Queue :");
     scanf("%d",&n);
     
     while(1)
     {
         printf("\nOperations:\n");
         printf("\n1.insertion\n2.deletion\n3.display\n4.exit\n");
         
         printf("\n\nenter your choice:");
         scanf("%d",&ch);
         
        switch(ch)
         {
             
             case 1:
             printf("\nEnter element to insert:");
             scanf("%d",&x);
             
             if(R==n-1){
            
            printf("\nOverflow");
            
             }
             else if(F==-1 &&R==-1){
                 
                 F=R=0;
                 Q[R] = x;
             }
             else{
                 
                 R++;
                 Q[R]= x;
             }
             break;
             
             case 2: 
             
             if(F ==-1 && R ==-1){
             
             printf("Underflow\n");
             
             }
             else if(F==R){
                 
              printf("Element deleted is %d", Q[F]);
              
              F = R =-1;
             }
              else{
                  printf("Element deleted is %d ",Q[F]);
                  F++;
              }
              break;
                  
             
                 
             case 3:
             if(F!=-1&&R!=-1)
             {
              printf("The element are:");
              for(i=F; i<=R; i++){
                  printf("%d",Q[i]);
              }
              
             }
             else{
                 
                 printf("Underflow\n");
                 
             }
             break;
             
             
             case 4:
             exit(0);
             break;
             
             default:
             
             printf("Invalid choice");
             break;
             
         }
     }
     return 0;
}
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
     